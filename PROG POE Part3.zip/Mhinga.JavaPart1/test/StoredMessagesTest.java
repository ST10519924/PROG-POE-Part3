/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

/**
 *
 * @author MAKHENSE MALVIN
 */
import static org.junit.Assert.*;
import java.io.File;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class StoredMessagesTest {

    private static final String TEST_FILE = "testStoredMessages.json";

    private StoredMessages stored;

    // Builds a fresh StoredMessages (using its own test file) with the test data
    @Before
    public void setUp() {
        new File(TEST_FILE).delete();

        stored = new StoredMessages(TEST_FILE);

        stored.addMessage("1234567890", "12:1:DIDCAKE", "+27834557896",
                "Did you get the cake?", "Sent", "Developer");
        stored.addMessage("0012345678", "00:2:WHERETIME", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.",
                "Stored", "Developer");
        stored.addMessage("2345678901", "23:3:YOHOOOOGATE", "+27834484567",
                "Yohoooo, I am at your gate.", "Disregarded", "Developer");
        stored.addMessage("3456789012", "34:4:ITTIME", "0838884567",
                "It is dinner time!", "Sent", "Developer");
        stored.addMessage("4567890123", "45:5:OKYOU", "+27838884567",
                "Ok, I am leaving without you.", "Stored", "Developer");
    }

    @After
    public void tearDown() {
        new File(TEST_FILE).delete();
    }

    // ---------- Sender and recipient of sent messages ----------

    @Test
    public void testDisplaySenderAndRecipient() {
        assertEquals("Sender: Developer | Recipient: +27834557896\n"
                + "Sender: Developer | Recipient: 0838884567\n",
                stored.displaySenderAndRecipient());
    }

    // ---------- Longest sent message ----------

    @Test
    public void testDisplayLongestSentMessage() {
        assertEquals("Did you get the cake?", stored.displayLongestSentMessage());
    }

    // ---------- Search by message ID ----------

    @Test
    public void testSearchByMessageIDFound() {
        assertEquals("Recipient: 0838884567\nMessage: It is dinner time!",
                stored.searchByMessageID("3456789012"));
    }

    @Test
    public void testSearchByMessageIDNotFound() {
        assertEquals("Message ID not found.", stored.searchByMessageID("0000000000"));
    }

    // ---------- Search by recipient (sent or stored) ----------

    @Test
    public void testSearchByRecipientFound() {
        assertEquals("Where are you? You are late! I have asked you to be on time.\n"
                + "Ok, I am leaving without you.\n",
                stored.searchByRecipient("+27838884567"));
    }

    @Test
    public void testSearchByRecipientIgnoresDisregarded() {
        assertEquals("No messages found for this recipient.",
                stored.searchByRecipient("+27834484567"));
    }

    // ---------- Delete by message hash ----------

    @Test
    public void testDeleteByMessageHashSuccess() {
        assertEquals("Message \"It is dinner time!\" successfully deleted.",
                stored.deleteByMessageHash("34:4:ITTIME"));
        assertEquals("Message ID not found.", stored.searchByMessageID("3456789012"));
    }

    @Test
    public void testDeleteByMessageHashFailure() {
        assertEquals("Message hash not found.", stored.deleteByMessageHash("99:9:NOPE"));
    }

    // ---------- Report of all sent messages ----------

    @Test
    public void testDisplayReport() {
        assertEquals("Message Hash: 12:1:DIDCAKE\n"
                + "Recipient: +27834557896\n"
                + "Message: Did you get the cake?\n\n"
                + "Message Hash: 34:4:ITTIME\n"
                + "Recipient: 0838884567\n"
                + "Message: It is dinner time!\n\n",
                stored.displayReport());
    }

    // ---------- JSON file ----------

    @Test
    public void testStoredMessagesSurviveReload() {
        StoredMessages reloaded = new StoredMessages(TEST_FILE);

        assertEquals("Recipient: +27838884567\n"
                + "Message: Ok, I am leaving without you.",
                reloaded.searchByMessageID("4567890123"));
    }

    @Test
    public void testDeletedStoredMessageStaysDeletedAfterReload() {
        stored.deleteByMessageHash("45:5:OKYOU");

        StoredMessages reloaded = new StoredMessages(TEST_FILE);

        assertEquals("Message ID not found.", reloaded.searchByMessageID("4567890123"));
    }
}
