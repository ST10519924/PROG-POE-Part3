/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 
/**
 *
 * @author MAKHENSE MALVIN
 */
import static org.junit.Assert.*;
import org.junit.Test;
 
public class MessageTest {
 
    // Helper: builds a Message using the real 4-argument constructor
    private Message makeMessage(String id, int number, String recipient, String text) {
        return new Message(id, number, recipient, text);
    }
 
    // ---------- Message ID ----------
 
    @Test
    public void testCheckMessageIDSuccess() {
        Message msg = makeMessage("1234567890", 1, "+27718659302", "Hello");
        assertTrue(msg.checkMessageID());
    }
 
    @Test
    public void testCheckMessageIDFailure() {
        Message msg = makeMessage("12345678901", 1, "+27718659302", "Hello");
        assertFalse(msg.checkMessageID());
    }
 
    // ---------- Recipient cell number ----------
 
    @Test
    public void testCheckRecipientCellSuccess() {
        Message msg = makeMessage("1234567890", 1, "+27718659302", "Hello");
        assertTrue(msg.checkRecipientCell());
    }
 
    @Test
    public void testCheckRecipientCellFailure() {
        Message msg = makeMessage("1234567890", 1, "0837097988", "Hello");
        assertFalse(msg.checkRecipientCell());
    }
 
    // ---------- Message length ----------
 
    @Test
    public void testCheckMessageLengthSuccess() {
        Message msg = makeMessage("1234567890", 1, "+27718659302",
                "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }
 
    @Test
    public void testCheckMessageLengthFailure() {
        String longMessage = new String(new char[251]).replace("\0", "a");
        Message msg = makeMessage("1234567890", 1, "+27718659302", longMessage);
        assertEquals("Message exceeds 250 characters by 1, please reduce the size.",
                msg.checkMessageLength());
    }
 
    // ---------- Message hash ----------
 
    @Test
    public void testCreateMessageHash() {
        Message msg = makeMessage("0012345678", 1, "+27718659302",
                "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:1:HITONIGHT", msg.createMessageHash());
    }
 
    // ---------- Send / disregard / store ----------
 
    @Test
    public void testSentMessageOption1() {
        Message msg = makeMessage("1234567890", 1, "+27718659302", "Hello there");
        assertEquals("Message successfully sent.", msg.SentMessage("1"));
    }
 
    @Test
    public void testSentMessageOption2() {
        Message msg = makeMessage("1234567890", 2, "+27718659302", "Hello there");
        assertEquals("Press 0 to delete the message.", msg.SentMessage("2"));
    }
 
    @Test
    public void testSentMessageOption3() {
        Message msg = makeMessage("1234567890", 3, "+27718659302", "Hello there");
        assertEquals("Message successfully stored.", msg.SentMessage("3"));
    }
}
 