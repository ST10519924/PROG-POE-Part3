/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MAKHENSE MALVIN
 */
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
        
public class StoredMessages {
    
    private final String jsonFile;
    
    
    private String[] sentMessage = new String[0];
    private String[] disregardedMessages = new String[0];
    private String[] storedMessages = new String[0];
    private String[] messageHash = new String[0];
    private String[] messageID = new String[0];
    
    
    private String[] recipient = new String[0];
    private String[] senders = new String[0];
    private String[] status = new String[0];
    
    
    private final List<MessageRecord> messages = new ArrayList<>();
    
    
    public StoredMessages(){
        this("storedMessages.json");
    }
    
    public StoredMessages(String jsonFile){
        this.jsonFile = jsonFile;
        loadStoredMessagesFromJSON();
        populateArrays();
    }
    
    private static class MessageRecord {
        String id;
        String hash;
        String recipient;
        String text;
        String status;
        String sender;
        
        MessageRecord(String id, String hash, String recipient, String text, 
                      String status, String sender){
            this.id = id;
            this.hash = hash;
            this.recipient = recipient;
            this.text = text;
            this.status = status;
            this.sender = sender;
        }
    }
    
    public void addMessage(String id, String hash, String recipient, String text, 
                      String status, String sender){
        
        messages.add(new MessageRecord(id, hash, recipient, text, status, "Developer"));
        
        populateArrays();
        
        if ("Stored".equalsIgnoreCase(status)){
            saveStoredMessagesToJSON();
        }
    }
    
    public final void populateArrays() {
        List<String> sent = new ArrayList<>();
        List<String> disregarded = new ArrayList<>();
        List<String> stored = new ArrayList<>();
        List<String> hashes = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        List<String> recipientList = new ArrayList<>();
        List<String> senderList = new ArrayList<>();
        List<String> statusList = new ArrayList<>();
        
        for (MessageRecord message : messages){
            hashes.add(message.hash);
            ids.add(message.id);
            recipientList.add(message.recipient);
            senderList.add(message.sender);
            statusList.add(message.status);
            
            if ("Sent".equalsIgnoreCase(message.status)){
                sent.add(message.text);
            } if ("Disregarded".equalsIgnoreCase(message.status)){
                disregarded.add(message.text);
            } if ("Stored".equalsIgnoreCase(message.status)){
                stored.add(message.text);
            }
        }
        
        sentMessage = sent.toArray(new String[0]);
        disregardedMessages = disregarded.toArray(new String[0]);
        storedMessages = stored.toArray(new String[0]);
        messageHash = hashes.toArray(new String[0]);
        messageID = ids.toArray(new String[0]);
        recipient = recipientList.toArray(new String[0]);
        senders = senderList.toArray(new String[0]);
        status = statusList.toArray(new String[0]);
    }
    
    //=====================================================
    //Load the stored messages from the JSON file
    //=====================================================
    
    private void loadStoredMessagesFromJSON() {
        
        messages.clear();
        
        Path path = Paths.get(jsonFile);
        
        if (!Files.exists(path)){
            return;
        }
        
        try {
            
            String content = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
            
            //Finds every "key": "value" pair in the file
            Pattern pair = Pattern.compile("\"(\\w+)\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
            Matcher matcher = pair.matcher(content);
            
            Map<String, String> fields = new LinkedHashMap<>();
            
            while (matcher.find()){
                
                String key = matcher.group(1);
                String value = unescapeJSON(matcher.group(2));
                
                //A new messageID means a new message has started
                if (key.equals("messageID") && !fields.isEmpty()){
                    addLoadedRecord(fields);
                    fields = new LinkedHashMap<>();
                }
                
                fields.put(key, value);
            }
            
            if (!fields.isEmpty()){
                addLoadedRecord(fields);
            }
            
        } catch (IOException e) {
            
            System.out.println("Error reading stored messages: " + e.getMessage());
        }
    }
    
    private void addLoadedRecord(Map<String, String> fields){
        
        //Messages saved by the Message class have no status or sender,
        //so they are treated as Stored messages from the Developer
        messages.add(new MessageRecord(
                fields.getOrDefault("messageID", ""),
                fields.getOrDefault("messageHash", ""),
                fields.getOrDefault("recipient", ""),
                fields.getOrDefault("message", ""),
                fields.getOrDefault("status", "Stored"),
                fields.getOrDefault("sender", "Developer")));
    }
    
    private static String unescapeJSON(String text){
        
        StringBuilder result = new StringBuilder();
        
        for (int i = 0; i < text.length(); i++){
            
            char ch = text.charAt(i);
            
            if (ch == '\\' && i + 1 < text.length()){
                
                char next = text.charAt(i + 1);
                i++;
                
                if (next == 'n'){
                    result.append('\n');
                } else {
                    result.append(next);
                }
                
            } else {
                result.append(ch);
            }
        }
        
        return result.toString();
    }
    
    private static String escapeJSON(String text){
        
        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n");
    }
    
    //=====================================================
    //Save the stored messages to the JSON file
    //=====================================================
    
    private void saveStoredMessagesToJSON() {
        
        List<MessageRecord> toSave = new ArrayList<>();
        
        for (MessageRecord message : messages){
            if ("Stored".equalsIgnoreCase(message.status)){
                toSave.add(message);
            }
        }
        
        try (FileWriter writer = new FileWriter(jsonFile)) {
            
            writer.write("[\n");
            
            for (int i = 0; i < toSave.size(); i++){
                
                MessageRecord stored = toSave.get(i);
                
                writer.write("  {\n");
                writer.write("    \"messageID\": \"" + escapeJSON(stored.id) + "\",\n");
                writer.write("    \"messageHash\": \"" + escapeJSON(stored.hash) + "\",\n");
                writer.write("    \"recipient\": \"" + escapeJSON(stored.recipient) + "\",\n");
                writer.write("    \"message\": \"" + escapeJSON(stored.text) + "\",\n");
                writer.write("    \"status\": \"" + escapeJSON(stored.status) + "\",\n");
                writer.write("    \"sender\": \"" + escapeJSON(stored.sender) + "\"\n");
                
                if (i < toSave.size() - 1){
                    writer.write("  },\n");
                } else {
                    writer.write("  }\n");
                }
            }
            
            writer.write("]");
            
        } catch (IOException e) {
            
            System.out.println("Error storing message: " + e.getMessage());
        }
    }
    
    //=====================================================
    //Bring in the messages from the Message class
    //(sent, disregarded and stored during this run)
    //=====================================================
    
    public void loadFromMessageClass() {
        
        for (Message sent : Message.getSentMessages()){
            addIfNew(sent, "Sent");
        }
        
        for (Message disregarded : Message.getDisregardedMessages()){
            addIfNew(disregarded, "Disregarded");
        }
        
        for (Message stored : Message.getStoredMessages()){
            addIfNew(stored, "Stored");
        }
        
        populateArrays();
    }
    
    private void addIfNew(Message m, String messageStatus){
        
        for (MessageRecord record : messages){
            if (record.id.equals(m.getMessageID())
                    && record.status.equalsIgnoreCase(messageStatus)){
                return;
            }
        }
        
        messages.add(new MessageRecord(m.getMessageID(), m.getMessageHash(),
                m.getRecipient(), m.getMessage(), messageStatus, "Developer"));
    }
    
    //=====================================================
    //a. Display the sender and recipient of all sent messages
    //=====================================================
    
    public String displaySenderAndRecipient() {
        
        String result = "";
        
        for (MessageRecord message : messages){
            if ("Sent".equalsIgnoreCase(message.status)){
                result = result + "Sender: " + message.sender
                        + " | Recipient: " + message.recipient + "\n";
            }
        }
        
        return result;
    }
    
    //=====================================================
    //b. Display the longest sent message
    //=====================================================
    
    public String displayLongestSentMessage() {
        
        String longest = "";
        
        for (MessageRecord message : messages){
            if ("Sent".equalsIgnoreCase(message.status)
                    && message.text.length() > longest.length()){
                longest = message.text;
            }
        }
        
        return longest;
    }
    
    //=====================================================
    //c. Search for a message ID and display the recipient and message
    //=====================================================
    
    public String searchByMessageID(String searchID) {
        
        for (MessageRecord message : messages){
            if (message.id.equals(searchID)){
                return "Recipient: " + message.recipient
                        + "\nMessage: " + message.text;
            }
        }
        
        return "Message ID not found.";
    }
    
    //=====================================================
    //d. Search for all the messages sent or stored for a recipient
    //=====================================================
    
    public String searchByRecipient(String searchRecipient) {
        
        String result = "";
        
        for (MessageRecord message : messages){
            if (message.recipient.equals(searchRecipient)
                    && ("Sent".equalsIgnoreCase(message.status)
                    || "Stored".equalsIgnoreCase(message.status))){
                result = result + message.text + "\n";
            }
        }
        
        if (result.isEmpty()){
            return "No messages found for this recipient.";
        }
        
        return result;
    }
    
    //=====================================================
    //e. Delete a message using the message hash
    //=====================================================
    
    public String deleteByMessageHash(String hash) {
        
        for (int i = 0; i < messages.size(); i++){
            
            MessageRecord message = messages.get(i);
            
            if (message.hash.equalsIgnoreCase(hash)){
                
                boolean wasStored = "Stored".equalsIgnoreCase(message.status);
                
                messages.remove(i);
                
                populateArrays();
                
                if (wasStored){
                    saveStoredMessagesToJSON();
                }
                
                return "Message \"" + message.text + "\" successfully deleted.";
            }
        }
        
        return "Message hash not found.";
    }
    
    //=====================================================
    //f. Display a report of all the sent messages
    //=====================================================
    
    public String displayReport() {
        
        String result = "";
        
        for (MessageRecord message : messages){
            if ("Sent".equalsIgnoreCase(message.status)){
                result = result
                        + "Message Hash: " + message.hash + "\n"
                        + "Recipient: " + message.recipient + "\n"
                        + "Message: " + message.text + "\n\n";
            }
        }
        
        return result;
    }
}